
% Selecting parameter by GCV function for regularized trignometric polynomial on the unit circle
%Input: N quadrature points x and corresponding noisy data Y for trapezoidal rule.  Penalization
%parameter mu. 
%Please note that our plotting are set for accommodating the plotting 
% requirments in our paper. If you choose to test another function, you may
% need to modify plotting setting.
% you can try different values of parameters N.
function lambda_gcv=parametergcv(N,mu,x,Y)
L=N-1;
 W1=ones(1,N);
w=((2*pi)/N)*W1;
%% matrix A 


 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
  end
   A1(:,1) =1/sqrt(2*pi);
   
lambda=2.^(-40:0.1:1);
for i=1:length(lambda)
beta_f1= l2_beta(w,A1,Y',0,L,mu);
A_lambda=((lambda(i)*mu.^2)./(1+lambda(i)*mu.^2)).*beta_f1';
Trace=N-sum(1./(1+lambda(i)*mu.^2));
gcv(i)=norm(A_lambda)^2/Trace^2;
end
%% lambda_opt
[v1,l1]=min(gcv);
lambda_gcv=lambda(l1);







