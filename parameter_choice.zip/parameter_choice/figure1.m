
clear all;close all
N=501;
L=500;
N1=501;
xx=-2*pi:4*pi/2000:2*pi;




x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;
   %% f_1(x) add noise      
G_f1= exp(cos(x));
G1_f1= exp(cos(x1));
GG_f1=  exp(cos(xx));
[Y_f1,NOISE_f1]=noisegen(G_f1,20);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,20);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,20);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;

%% f_2(x) add noise
       % OO=chebop(0,2*pi)
%OO.op=@(x,u) 0.001*diff(u,2)+0.001*diff(u)-cos(x).*u; 
% OO.bc='periodic';
%oo=OO\0.1;
%G_f2=oo(x);
% G1_f2=oo(x1);
% GG_f2=oo(xx);
G_f2= sin(30*x)+exp(cos(x));
G1_f2= sin(30*x1)+exp(cos(x1));
GG_f2=  sin(30*xx)+exp(cos(xx));
[Y_f2,NOISE_f2]=noisegen(G_f2,20);
[YY_f2,NOISE1_f2]=noisegen(G1_f2,20);
[yy_f2,NOISE2_f2]=noisegen(GG_f2,20);
delta_f1=(2*pi/N)*norm(NOISE_f2)^2;

 %% f_3(x) with h=3 add noise 
G_f3=sawtooth(x,1/2)+exp(cos(x));
GG_f3=sawtooth(xx,1/2)+exp(cos(xx));
G1_f3=sawtooth(x1,1/2)+exp(cos(x1));
[Y_f3,NOISE_f3]=noisegen(G_f3,10);
[YY_f3,NOISE1_f3]=noisegen(G1_f3,10);
[yy_f3,NOISE2_f3]=noisegen(GG_f3,10);
delta_f3=norm(NOISE2_f3);
%% matrix A 
 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
   end
   A1(:,1) =1/sqrt(2*pi);
    for l = 1:L+1
      for j = 1:length(xx)
       
    if mod(l, 2) == 0
       C(j,l) =sin(((l)/2)*(xx(j)))/sqrt(pi);
  
    else
      C(j,l) = cos(((l-1)/2)*(xx(j)))/sqrt(pi);
   
    end
      end
    end
  
C(:,1) =1/sqrt(2*pi);


%% determin beta
s=1;
for i=1:L/2+1
z_f1(i)=(i-1)^(2*s);
%z_f2(i)=(a2)^i/c2;
% z_f2(i)=(i)^(a2)/c2;
z_f2(i)=(i-1)^(2*s);
z_f3(i)=(i-1)^(2*s);
end
for j=2:L+1
    if mod(j, 2) == 0
        mu_f1(j)=z_f1(j/2+1);
        mu_f2(j)=z_f2(j/2+1);
        mu_f3(j)=z_f3(j/2+1);
    else
    
        mu_f1(j)=mu_f1(j-1);
         mu_f2(j)=mu_f2(j-1);
         mu_f3(j)=mu_f3(j-1);
    end
end
mu_f1(1)=z_f1(1);  
mu_f1= mu_f1';
mu_f2(1)=z_f2(1);  
mu_f2= mu_f2';
mu_f3(1)=z_f1(1);  
mu_f3= mu_f3';
 



lambda_f1=2.^(-40:0.1:-1);
lambda_f2=2.^(-40:0.1:-1);
lambda_f3=2.^(-40:0.1:-1);
Beta_f1 = l2_beta(w,A1,Y_f1',0,L,mu_f1);
Beta_f3 = l2_beta(w,A1,G_f3',0,L,mu_f3);
for i=1:length(lambda_f1)
beta_f1 = l2_beta(w,A1,Y_f1',lambda_f1(i),L,mu_f2);
error_L2_f1(i)=norm(sqrt(diag(w))*(A1*beta_f1'-Y_f1'))^2;
noise_L2_f1(i)=norm(sqrt(diag(w))*(A1*(mu_f1.*beta_f1')))^2;
Error_L2_f1(i)=(2*pi/N)*norm(beta_f1*C'-GG_f1)^2;
Error_inf_f1(i)=norm(beta_f1*C'-GG_f1,inf);
end
for i=1:length(lambda_f2)
beta_f2 = l2_beta(w,A1,Y_f2',lambda_f2(i),L,mu_f2);
error_L2_f2(i)=norm(sqrt(diag(w))*(A1*beta_f2'-Y_f2'))^2;
noise_L2_f2(i)=norm(sqrt(diag(w))*(A1*(mu_f2.*beta_f2')))^2;
Error_L2_f2(i)=(2*pi/N)*norm(beta_f2*C'-GG_f2)^2;
Error_inf_f2(i)=norm(beta_f2*C'-GG_f2,inf);
end



[v,l]=min(error_L2_f2);
lambda_opt2=lambda_f2(l);
beta_optf2=l2_beta(w,A1,Y_f1',lambda_opt2,L,mu_f1);
p_optf2= beta_optf2*C';
 % subplot(2,2,1);semilogx(lambda_f1,error_L2_f1);
% subplot(2,2,2);semilogx(lambda_f1,error_inf_f1);
 % subplot(2,2,3);semilogx(lambda_f2,error_L2_f2);
 % subplot(2,2,4);semilogx(lambda_f2,error_inf_f2);
fontsize_baselinet=12;
fontsize_baseline=12;
Color = [215,25,28;
0 0 128;
254,204,92;
171,217,233;
44,123,182]/255;

axes('position',[0.15 0.58 0.3 0.38]),
loglog(lambda_f1,sqrt(Error_L2_f1),'-','color',  Color(5,:),'linewidth',1.5);box on,...
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'on'),%set(gca,'YTick',[0.1  0.5 1 1.5 2 2.5]); 
set(gca, 'YMinorGrid', 'off');grid on;
xlim([lambda_f1(1),lambda_f1(length(lambda_f1))]);
title('$L_2$ error for approximating $f_1(x)$ with $N=501,\;L=250$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Regularizaiton parameter $\lambda$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('$L_2$ error', 'interpreter','latex','fontsize', fontsize_baselinet),...

 axes('position',[0.5 0.58 0.3 0.38]),
loglog(lambda_f1,Error_inf_f1,'-','color',  Color(5,:),'linewidth',1.5);box on,...
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'on'),%set(gca,'YTick',[0.25 0.5 0.75 1 1.25 1.5]);
set(gca, 'YMinorGrid', 'off');grid on;
xlim([lambda_f1(1),lambda_f1(length(lambda_f1))]);
title('Uniform error for approximating $f_1(x)$ with $N=501,\;L=250$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Regularizaiton parameter $\lambda$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel(' Uniform error', 'interpreter','latex','fontsize', fontsize_baselinet),...

axes('position',[0.15 0.08 0.3 0.38]),
loglog(lambda_f2,sqrt(Error_L2_f2),'-','color',  Color(5,:),'linewidth',1.5);box on,...
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'on'),% set(gca,'YTick',[1  1.5 2.5 3.5 4]); 
set(gca, 'YMinorGrid', 'off');grid on;
xlim([lambda_f1(1),lambda_f1(length(lambda_f1))]);
title('$L_2$ error for approximating $f_2(x)$ with $N=501,\;L=250$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Regularizaiton parameter $\lambda$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('$L_2$ error', 'interpreter','latex','fontsize', fontsize_baselinet),...



axes('position',[0.5 0.08 0.3 0.38]),
loglog(lambda_f2,Error_inf_f2,'-','color',  Color(5,:),'linewidth',1.5);box on,...
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'on'),%set(gca,'YTick',[  0.5  1 1.5  2 2.5]);
set(gca, 'YMinorGrid', 'off');grid on;
% xlim([lambda_f1(1),lambda_f1(length(lambda_f1))]);
title('Uniform error for approximating $f_2(x)$ with $N=501,\;L=250$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Regularizaiton parameter $\lambda$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel(' Uniform error', 'interpreter','latex','fontsize', fontsize_baselinet),...

