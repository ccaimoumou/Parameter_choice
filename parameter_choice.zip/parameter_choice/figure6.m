clear all;close all
N=501;
N1=501;
L=500;
xx=-3*pi:6*pi/2000:3*pi;
x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;

   %% f_1(x) add noise      
G_f1 = exp(cos(x));
GG_f1 = exp(cos(xx));
G1_f1=exp(cos(x1));
 G_f2= exp(cos(x))+sin(30*x); 
 GG_f2= exp(cos(xx))+sin(30*xx);
 G1_f2=exp(cos(x1))+sin(30*x1);        

error_level=10:5:100;
s=2;
for i=1:L/2+1
z(i)=(i-1)^(s);
end
for j=2:L+1
    if mod(j, 2) == 0
        mu(j)=z(j/2+1);     
    else
    
       mu(j)=mu(j-1);        
    end
end
mu(1)=z(1);  
mu= mu';
s=1;
for e=10:5:100

    
[Y_f1,NOISE_f1]=noisegen(G_f1,e);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,e);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,e);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;

[Y_f2,NOISE_f2]=noisegen(G_f2,e);
[YY_f2,NOISE1_f2]=noisegen(G1_f2,e);
[yy_f2,NOISE2_f2]=noisegen(GG_f2,e);
delta_f2=(2*pi/N)*norm(NOISE_f2)^2;


%% ����ѡȡ
lambda_corner_f1(s)=parametercorner(N,mu,x,Y_f1);
lambda_gcv_f1(s)=parametergcv(N,mu,x,Y_f1);
lambda_mor_f1(s)=parametermor(N,mu,x,Y_f1,delta_f1);
lambda_opt_f1(s)=parameteropt(N,mu,x,xx,GG_f1,Y_f1);

lambda_corner_f2(s)=parametercorner(N,mu,x,Y_f2);
lambda_gcv_f2(s)=parametergcv(N,mu,x,Y_f2);
lambda_mor_f2(s)=parametermor(N,mu,x,Y_f2,delta_f2);
lambda_opt_f2(s)=parameteropt(N,mu,x,xx,GG_f2,Y_f2);

s=s+1;
end

fontsize_baselinet=20;
fontsize_baseline=20;
Color = [215,25,28;
0 0 128;
254,204,92;
171,217,233;
44,123,182]/255;
 axes('position',[0.08 0.1 0.4 0.85]),
 semilogy(error_level,lambda_opt_f1,'V-','color', Color(1,:),'linewidth',1.2);box on,...
hold on
semilogy(error_level,lambda_mor_f1,'s-','color', Color(2,:),'linewidth',1.2);
semilogy(error_level,lambda_corner_f1,'-o','color', Color(5,:),'linewidth',1.2);
semilogy(error_level,lambda_gcv_f1,'-p','color', Color(3,:),'linewidth',1.2);
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off');
 xlim([error_level(1),error_level(length(error_level))]);
title('Values of three parameter choice strateges for $f_1(x)$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Noise level (dB)','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('Parameter values', 'interpreter','latex','fontsize', fontsize_baselinet),...
legend('$\lambda_{{\rm opt}}$','$\lambda_{{\rm mor}}$','$\lambda_{{\rm corner}}$','$\lambda_{{\rm gcv}}$','Interpreter','latex','Fontsize',12,'fontsize', fontsize_baseline)


axes('position',[0.56 0.1 0.4 0.85]),
semilogy(error_level,lambda_opt_f2,'V-','color', Color(1,:),'linewidth',1.2);box on,...
hold on
semilogy(error_level,lambda_mor_f2,'s-','color', Color(2,:),'linewidth',1.2);
semilogy(error_level,lambda_corner_f2,'-o','color', Color(5,:),'linewidth',1.2);
semilogy(error_level,lambda_gcv_f2,'-p','color', Color(3,:),'linewidth',1.2);
set(gca, 'fontsize', fontsize_baseline),set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off');
 xlim([error_level(1),error_level(length(error_level))]);
title('Values of three parameter choice strateges for $f_2(x)$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('Noise level (dB)','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('Parameter values', 'interpreter','latex','fontsize', fontsize_baselinet),...
legend('$\lambda_{{\rm opt}}$','$\lambda_{{\rm mor}}$','$\lambda_{{\rm corner}}$','$\lambda_{{\rm gcv}}$','Interpreter','latex','Fontsize',12,'fontsize', fontsize_baseline)











