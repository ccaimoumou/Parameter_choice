clear all;close all

N=1001;
N1=1001;
L=1000;
xx=-3*pi:6*pi/2000:3*pi;
x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;

   %% f_1(x) add noise      
 f=cheb.gallerytrig('wavepacket');
 G_f1=f(x);
 GG_f1=f(xx);
 G1_f1=f(x1);
[Y_f1,NOISE_f1]=noisegen(G_f1,10);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,10);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,10);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;

%% f_2(x) add noise
 f=cheb.gallerytrig('fmsignal');
 G_f2=f(x);GG_f2=f(xx);
 G1_f2=f(x1);
[Y_f2,NOISE_f2]=noisegen(G_f2,10);
[YY_f2,NOISE1_f2]=noisegen(G1_f2,10);
[yy_f2,NOISE2_f2]=noisegen(GG_f2,10);
delta_f2=(2*pi/N)*norm(NOISE_f2)^2;

 %% f_3(x) with h=3 add noise 
f=cheb.gallerytrig('tsunami');
G_f3=f(x);GG_f3=f(xx);
G1_f3=f(x1);
[Y_f3,NOISE_f3]=noisegen(G_f3,10);
[YY_f3,NOISE1_f3]=noisegen(G1_f3,10);
[yy_f3,NOISE2_f3]=noisegen(GG_f3,10);
delta_f3=(2*pi/N)*norm(NOISE_f3)^2;

 %% f_4(x) add noise
 f=cheb.gallerytrig('random');
 G_f4=f(x);GG_f4=f(xx);
 G1_f4=f(x1);
[Y_f4,NOISE_f4]=noisegen(G_f4,10);
[YY_f4,NOISE1_f4]=noisegen(G1_f4,10);
[yy_f4,NOISE2_f4]=noisegen(GG_f4,10);
delta_f4=(2*pi/N)*norm(NOISE_f4)^2;


%% matrix A 
s=1;
A1=[];C=[];mu_f1=[];
 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
   end
   A1(:,1) =1/sqrt(2*pi);
    for l = 1:L+1
      for j = 1:length(xx)
    if mod(l, 2) == 0
       C(j,l) =sin(((l)/2)*(xx(j)))/sqrt(pi);
  
    else
      C(j,l) = cos(((l-1)/2)*(xx(j)))/sqrt(pi);
   
    end
      end
    end
  
C(:,1) =1/sqrt(2*pi);


for i=1:L/2+1
z(i)=(i-1)^(2*s);
end
for j=2:L+1
    if mod(j, 2) == 0
        mu(j)=z(j/2+1);     
    else
    
       mu(j)=mu(j-1);        
    end
end
mu(1)=z(1);  
mu= mu';

%% 参数选取
random_number = randn;
uniform_random_number = normcdf(random_number);
while uniform_random_number <= 0 || uniform_random_number >= 0.1
    random_number = randn;  
    uniform_random_number = normcdf(random_number);
end

lambda_random_f3=uniform_random_number ;
lambda_gcv_f3=parametergcv(N,mu,x,Y_f3);
lambda_corner_f3=parametercorner(N,mu,x,Y_f3);



%% determin regularization solution
beta_f3 = l2_beta(w,A1,Y_f3',0,L,mu);
beta_random_f3 = l2_beta(w,A1,Y_f3',lambda_random_f3,L,mu);
beta_corner_f3 = l2_beta(w,A1,Y_f3',lambda_corner_f3,L,mu);
beta_gcv_f3 = l2_beta(w,A1,Y_f3',lambda_gcv_f3,L,mu);




%% approximation trigonometric polynomial

 
   p_f3=beta_f3*C'; error_f3=abs(p_f3-GG_f3);


 p_f3_corner=beta_corner_f3*C'; error_f3_corner=abs(p_f3_corner-GG_f3);

 p_f3_gcv=beta_gcv_f3*C'; error_f3_gcv=abs(p_f3_gcv-GG_f3);
 
 
 p_f3_random=beta_random_f3*C'; error_f3_random=abs(p_f3_random-GG_f3);
 
 
fontsize_baselinet = 11;
fontsize_baseline = 7.6;
Color = [215,25,28;
    0 0 128;
    254,204,92;
    171,217,233;
    44,123,182;
    255*0.8500 255*0.3250 255*0.0980;
    255*0.4940 255*0.1840 255*0.5560]/255;
interspace = 5;

% 图第三行
axes('position',[0.017 0.54 0.23 0.425]),
plot(xx,GG_f3,'color',Color(2,:),'linewidth',1.2); 
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on; 
title('\texttt{tsunami}','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, -0.1,0.2])


axes('position',[0.267 0.54 0.23 0.425]),
plot(xx,p_f3_random,'color',Color(2,:),'linewidth',1.2); 
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on;
title('Regularization \texttt{tsunami} with $\lambda_{\rm{random}}$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, -0.1,0.2])

axes('position',[0.517 0.54 0.23 0.425]),
plot(xx,p_f3_gcv,'color',Color(2,:),'linewidth',1.2); 
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on;
title('regularization \texttt{tsunami} with $\lambda_{\rm{gcv}}$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, -0.1,0.2])


axes('position',[0.767 0.54 0.23 0.425]),
plot(xx,p_f3_corner,'color',Color(2,:),'linewidth',1.2); 
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on;
title('regularization \texttt{tsunami} with $\lambda_{\rm{corner}}$','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, -0.1,0.2])



% 图第四行
axes('position',[0.017 0.045 0.23 0.425]),  
plot(xx,yy_f3,'color',Color(2,:),'linewidth',1.2); 
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on; 
title('Noisy \texttt{tsunami}','interpreter','latex', 'fontsize', fontsize_baselinet)
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, -0.1,0.2])



axes('position',[0.267 0.045 0.23 0.425]),
plot(xx(1:interspace:length(xx)),error_f3_random(1:interspace:length(error_f3_random)),'color',Color(2,:),'linewidth',1.2); 
title('Errors','interpreter','latex', 'fontsize', fontsize_baselinet)
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on; 
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, 0,0.2])


axes('position',[0.517 0.045 0.23 0.425]),
plot(xx(1:interspace:length(xx)),error_f3_gcv(1:interspace:length(error_f3_gcv)),'color',Color(2,:),'linewidth',1.2); 
title('Errors','interpreter','latex', 'fontsize', fontsize_baselinet)
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on; 
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, 0,0.2])

axes('position',[0.767 0.045 0.23 0.425]),
plot(xx(1:interspace:length(xx)),error_f3_corner(1:interspace:length(error_f3_corner)),'color',Color(2,:),'linewidth',1.2); 
title('Errors','interpreter','latex', 'fontsize', fontsize_baselinet)
set(gca, 'fontsize', fontsize_baseline), set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'), grid on; 
xlabel('$x$ ','interpreter','latex', 'fontsize', fontsize_baselinet)
axis([-2,2, 0,0.2])



