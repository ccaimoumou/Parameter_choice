% IMPORTANT! Please add the Chebfun Toolbox 
% onto path before running this demo

% regularized trignometric ploymial approximation on the unit circle

% Please note that our plotting are set for accommodating the plotting 
% requirments in our paper. If you choose to test another function, you may
% need to modify plotting setting.
% you can try different values of parameters N.


clear all;close all
N=501;
N1=501;
L=500;
xx=-3*pi:6*pi/2000:3*pi;
x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;

  % testing periodic function
   example_idx=2;
switch example_idx
  case 1
       OO=chebop(0,2*pi);
OO.op=@(x,u) 0.001*diff(u,2)+0.001*diff(u)-cos(x).*u; 
OO.bc='periodic';
oo=OO\0.1;
G_f1=oo(x);
G1_f1=oo(x1);
GG_f1=oo(xx);
case 2    
     G_f1 = exp(cos(x)); GG_f1 = exp(cos(xx));G1_f1=exp(cos(x1));
 case 3
       G_f1=cos(50*x).*(1+cos(5*x)/5);GG_f1=cos(50*xx).*(1+cos(5*xx)/5);G1_f1=cos(50*x1).*(1+cos(5*x1)/5);
    case 4
     f=cheb.gallerytrig('wavepacket');G_f1=f(x);GG_f1=f(xx);G1_f1=f(x1);
    case 5
        f=cheb.gallerytrig('tsunami');G_f1=f(x);GG_f1=f(xx);G1_f1=f(x1);
    case 6 
           f=cheb.gallerytrig('random');G_f1=f(x);GG_f1=f(xx);G1_f1=f(x1);
     case 7 
           f=cheb.gallerytrig('gibbs');G_f1=f(x);GG_f1=f(xx);G1_f1=f(x1);
      case 8 
          G_f1 = exp(cos(x))+sin(30*x); GG_f1 = exp(cos(xx))+sin(30*xx);G1_f1=exp(cos(x1))+sin(30*x1);                 
end
  
%addding noise, noise level is determined by db, the less db, the higher
%noise.
db=20;
[Y_f1,NOISE_f1]=noisegen(G_f1,db);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,db);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,db);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;
for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
  end
   A1(:,1) =1/sqrt(2*pi);

%Penalization parameter
for i=1:L/2+1
z(i)=(i-1)^(2);
end
for j=2:L+1
    if mod(j, 2) == 0
        mu(j)=z(j/2+1);     
    else
    
       mu(j)=mu(j-1);        
    end
end
mu(1)=z(1);  
mu= mu';

%% Consequences 
lambda_mor=parametermor(N,mu,x,Y_f1,delta_f1)
lambda_gcv=parametergcv(N,mu,x,Y_f1)
lambda_corner=parametercorner(N,mu,x,Y_f1)
lambda_opt=parameteropt(N,mu,x,xx,GG_f1,Y_f1)
