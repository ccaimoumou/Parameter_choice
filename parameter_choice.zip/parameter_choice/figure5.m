clear all;close all

N=501;
N1=501;
t=1;
s=1;
xx=-3*pi:6*pi/2000:3*pi;
x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;

   %% f(x) add noise      
   
     G_f1= exp(cos(x)); GG_f1 = exp(cos(xx));G1_f1=exp(cos(x1));
          

 
[Y_f1,NOISE_f1]=noisegen(G_f1,20);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,20);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,20);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;

for i=1:(N-1)/2+1
z(i)=(i-1)^(2*s);
end
for j=2:(N-1)+1
    if mod(j, 2) == 0
        mu(j)=z(j/2+1);     
    else
    
       mu(j)=mu(j-1);        
    end
end
mu(1)=z(1);  
mu= mu';
lambda_corner_f1=parametercorner(N,mu,x,Y_f1);
lambda_gcv_f1=parametergcv(N,mu,x,Y_f1);
lambda_mor_f1=parametermor(N,mu,x,Y_f1,delta_f1);
lambda_opt_f1=parameteropt(N,mu,x,xx,GG_f1,Y_f1);
mu=[];

for L=6:2:500
s=1;
A1=[];C=[];mu_f1=[];
 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
   end
   A1(:,1) =1/sqrt(2*pi);
    for l = 1:L+1
      for j = 1:length(xx)
    if mod(l, 2) == 0
       C(j,l) =sin(((l)/2)*(xx(j)))/sqrt(pi);
  
    else
      C(j,l) = cos(((l-1)/2)*(xx(j)))/sqrt(pi);
   
    end
      end
    end
  
C(:,1) =1/sqrt(2*pi);


for i=1:L/2+1
z(i)=(i-1)^(2*s);
end
for j=2:L+1
    if mod(j, 2) == 0
        mu(j)=z(j/2+1);     
    else
    
       mu(j)=mu(j-1);        
    end
end
mu(1)=z(1);  
mu= mu';

beta_f1= l2_beta(w,A1,Y_f1',0,L,mu);
beta_corner_f1 = l2_beta(w,A1,Y_f1',lambda_corner_f1,L,mu);
beta_mor_f1= l2_beta(w,A1,Y_f1',lambda_mor_f1,L,mu);
beta_gcv_f1= l2_beta(w,A1,Y_f1',lambda_gcv_f1,L,mu);
beta_opt_f1= l2_beta(w,A1,Y_f1',lambda_opt_f1,L,mu);



p_f1=beta_f1*C'; 
p_corner_f1=beta_corner_f1*C'; 
p_opt_f1=beta_opt_f1*C'; 
p_gcv_f1=beta_gcv_f1*C'; 
p_mor_f1=beta_mor_f1*C'; 




  Error_L2_f1(t)=((2*pi)/N)*norm(p_f1-GG_f1)^2;
Error_L2_opt_f1(t)=((2*pi)/N)*norm(p_opt_f1-GG_f1)^2;
 Error_L2_mor_f1(t)=((2*pi)/N)*norm(p_mor_f1-GG_f1)^2;
  Error_L2_corner_f1(t)=((2*pi)/N)*norm(p_corner_f1-GG_f1)^2;
Error_L2_gcv_f1(t)=((2*pi)/N)*norm(p_gcv_f1-GG_f1)^2;
  
  
Error_inf_f1(t)=norm(p_f1-GG_f1,inf);
Error_inf_opt_f1(t)=norm(p_opt_f1-GG_f1,inf);
 Error_inf_mor_f1(t)=norm(p_mor_f1-GG_f1,inf);
Error_inf_corner_f1(t)=norm(p_corner_f1-GG_f1,inf);
Error_inf_gcv_f1(t)=norm(p_gcv_f1-GG_f1,inf);


t=t+1;
end

Color = [215,25,28;
0 0 128;
254,204,92;
102, 0, 204;
255,255,255]/255;

fontsize_baseline = 13.2;
fontsize_baselinet = 13.2;
fontsize_baselinea = 13.2;
 axes('position',[0.08 0.1 0.4 0.85]),
semilogy(1:length(Error_L2_f1),Error_L2_f1,'.','linewidth',1.8)
hold on
semilogy(1:length(Error_L2_opt_f1),Error_L2_opt_f1,'--','linewidth',2)
semilogy(1:length(Error_L2_mor_f1),Error_L2_mor_f1,':','color',Color(4,:),'linewidth',2)
semilogy(1:length(Error_L2_corner_f1),Error_L2_corner_f1,'k-','linewidth',2)
semilogy(1:length(Error_L2_gcv_f1),Error_L2_gcv_f1,'-.','color',Color(2,:),'linewidth',1.2)
 set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('Degree $L$','interpreter','latex', 'fontsize', fontsize_baseline),...
    ylabel('Error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('$L_2$ error for exp(cos(x))','interpreter','latex', 'fontsize', fontsize_baselinet),...
     legend('No regularization','$\lambda_{{\rm opt}}$','$\lambda_{{\rm mor}}$',...
 '$\lambda_{{\rm corner}}$','$\lambda_{{\rm gcv}}$','Interpreter','latex','Fontsize',10,'fontsize', fontsize_baseline,'Location','northwest')
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),

axes('position',[0.56 0.1 0.4 0.85]),
semilogy(1:length(Error_inf_f1),Error_inf_f1,'.','linewidth',1.8)
hold on
semilogy(1:length(Error_inf_opt_f1),Error_inf_opt_f1,'--','linewidth',2)
semilogy(1:length(Error_inf_mor_f1),Error_inf_mor_f1,':','color',Color(4,:),'linewidth',2)
semilogy(1:length(Error_inf_corner_f1),Error_inf_corner_f1,'k-','linewidth',1.2)
semilogy(1:length(Error_inf_gcv_f1),Error_inf_gcv_f1,'-.','color',Color(2,:),'linewidth',1.2)
 set(gca, 'fontsize', fontsize_baselinea),...
    xlabel('Degree $L$','interpreter','latex', 'fontsize', fontsize_baseline),...
    ylabel('Error','interpreter','latex', 'fontsize', fontsize_baseline),...
    title('Uniform error for exp(cos(x))','interpreter','latex', 'fontsize', fontsize_baselinet),...
     legend('No regularization','$\lambda_{{\rm opt}}$','$\lambda_{{\rm mor}}$',...
 '$\lambda_{{\rm corner}}$','$\lambda_{{\rm gcv}}$','Interpreter','latex','Fontsize',10,'fontsize', fontsize_baseline,'Location','northwest')
     set(gca, 'XMinorGrid', 'off'), set(gca, 'YMinorGrid', 'off'),

















