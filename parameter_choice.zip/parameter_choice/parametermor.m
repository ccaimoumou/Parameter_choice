% Selecting parameter by Morozov’s discrepancy principal for regularized trignometric polynomial on the unit circle
%Input: N quadrature points x and corresponding noisy data Y for trapezoidal rule.  Penalization
%parameter mu. Noise level delta.
%delta is designed by weighted norm, that delta=(2*pi/N)*norm(f+epsilon)^2, where epsilon is Gaussion white noise;
%Please note that our plotting are set for accommodating the plotting 
% requirments in our paper. If you choose to test another function, you may
% need to modify plotting setting.
% you can try different values of parameters N.

function lambda_mor=parametermor(N,mu,x,Y,delta)
L=N-1;
 W1=ones(1,N);
w=((2*pi)/N)*W1;
%% matrix A 


 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
  end
   A(:,1) =1/sqrt(2*pi);


lambda=2.^(-40:0.1:1);
for i=1:length(lambda)
beta = l2_beta(w,A,Y',lambda(i),L,mu);
error_L2(i)=norm(sqrt(diag(w))*(A*beta'-Y'))^2;
noise_L2(i)=norm(sqrt(diag(w))*(A*(mu.*beta')))^2;
discrepancy(i)=error_L2(i)-delta;
end
%% lambda_mor
for j=1:length(discrepancy)
    if discrepancy(j)>0
        u=j;
    break
    end
end
lambda_mor=lambda(u);







