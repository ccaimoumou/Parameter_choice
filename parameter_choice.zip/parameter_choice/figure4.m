clear all;close all
N=1001;
L=1000;
N1=501;
xx=-3*pi:6*pi/2000:3*pi;




x=(2*pi)/N:(2*pi)/N:2*pi;
x1=(2*pi)/N1:(2*pi)/N1:2*pi;
 W1=ones(1,N);
w=((2*pi)/N)*W1;
   %% f_1(x) add noise   
 G_f1= exp(cos(x));
G1_f1= exp(cos(x1));
GG_f1= exp(cos(xx));
  
[Y_f1,NOISE_f1]=noisegen(G_f1,20);
[YY_f1,NOISE1_f1]=noisegen(G1_f1,20);
[yy_f1,NOISE2_f1]=noisegen(GG_f1,20);
delta_f1=(2*pi/N)*norm(NOISE_f1)^2;

%% f_2(x) add noise
 G_f2= sin(30*x)+exp(cos(x));
G1_f2= sin(30*x1)+exp(cos(x1));
GG_f2=  sin(30*xx)+exp(cos(xx));
[Y_f2,NOISE_f2]=noisegen(G_f2,20);
[YY_f2,NOISE1_f2]=noisegen(G1_f2,20);
[yy_f2,NOISE2_f2]=noisegen(GG_f2,20);
delta_f1=(2*pi/N)*norm(NOISE_f2)^2;

 %% f_3(x) with h=3 add noise 
G_f3=tanh(20*sin(12*x))+0.02*exp(3*cos(x)).*sin(300*x);
GG_f3=tanh(20*sin(12*xx))+0.02*exp(3*cos(xx)).*sin(300*xx);
G1_f3=tanh(20*sin(12*x1))+0.02*exp(3*cos(x1)).*sin(300*x1);
[Y_f3,NOISE_f3]=noisegen(G_f3,30);
[YY_f3,NOISE1_f3]=noisegen(G1_f3,30);
[yy_f3,NOISE2_f3]=noisegen(GG_f3,30);
delta_f3=norm(NOISE2_f3);
%% matrix A 
 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
   end
   A1(:,1) =1/sqrt(2*pi);
    for l = 1:L+1
      for j = 1:length(xx)
       
    if mod(l, 2) == 0
       C(j,l) =sin(((l)/2)*(xx(j)))/sqrt(pi);
  
    else
      C(j,l) = cos(((l-1)/2)*(xx(j)))/sqrt(pi);
   
    end
      end
    end
  
C(:,1) =1/sqrt(2*pi);


%% determin beta
s=1;
for i=1:L/2+1
z_f1(i)=(i-1)^(2*s);
% z_f1(i)=1;
z_f2(i)=(i-1)^(2*s);

end
for j=2:L+1
    if mod(j, 2) == 0
        mu_f1(j)=z_f1(j/2+1);
        mu_f2(j)=z_f2(j/2+1);
    
    else
    
        mu_f1(j)=mu_f1(j-1);
         mu_f2(j)=mu_f2(j-1);
     
    end
end
mu_f1(1)=z_f1(1);  
mu_f1= mu_f1';
mu_f2(1)=z_f2(1);  
mu_f2= mu_f2';

 
w_f1=w.*mu_f1;
w_f2=w.*mu_f2;

lambda_f1=2.^(-25:0.1:1);
lambda_f2=2.^(-32:0.1:-19);
for i=1:length(lambda_f1)
 % kappa(i)=sum(lcurve_beta(w,A1,Y_f1',lambda_f1(i),L,mu_f1))^(-1);
beta_f1 = l2_beta(w,A1,Y_f1',lambda_f1(i),L,mu_f1);
error_L2_f1(i)=(norm(sqrt(diag(w))*(A1*beta_f1'-Y_f1')))^2;
noise_L2_f1(i)=(norm(sqrt(diag(w))*(A1*(mu_f1.*beta_f1'))))^2;
end

for i=1:length(lambda_f2)
 % kappa(i)=sum(lcurve_beta(w,A1,Y_f1',lambda_f1(i),L,mu_f1))^(-1);
beta_f2 = l2_beta(w,A1,Y_f2',lambda_f2(i),L,mu_f2);
error_L2_f2(i)=(norm(sqrt(diag(w))*(A1*beta_f2'-Y_f2')))^2;
noise_L2_f2(i)=(norm(sqrt(diag(w))*(A1*(mu_f2.*beta_f2'))))^2;
end

logerror_L2_f1=log(error_L2_f1);logerror_L2_f2=log(error_L2_f2);
lognoise_L2_f1=log(noise_L2_f1);lognoise_L2_f2=log(noise_L2_f2);
dx_f1  = 0.5*(logerror_L2_f1(3:end)-logerror_L2_f1(1:end-2)); dx_f2 = 0.5*(logerror_L2_f2(3:end)-logerror_L2_f2(1:end-2));
dy_f1  = 0.5*(lognoise_L2_f1(3:end)-lognoise_L2_f1(1:end-2)); dy_f2  = 0.5*(lognoise_L2_f2(3:end)-lognoise_L2_f2(1:end-2));
dl_f1  = sqrt(dx_f1.^2 + dy_f1.^2); dl_f2  = sqrt(dx_f2.^2 + dy_f2.^2);
xp_f1  = dx_f1./dl_f1; xp_f2  = dx_f2./dl_f2;
yp_f1  = dy_f1./dl_f1; yp_f2  = dy_f2./dl_f2;
% approximate 2nd derivatives of x & y with discrete differences
xpp_f1 = (logerror_L2_f1(3:end)-2*logerror_L2_f1(2:end-1)+logerror_L2_f1(1:end-2))./(dl_f1.^2);
xpp_f2 = (logerror_L2_f2(3:end)-2*logerror_L2_f2(2:end-1)+logerror_L2_f2(1:end-2))./(dl_f2.^2);

ypp_f1 = (lognoise_L2_f1(3:end)-2*lognoise_L2_f1(2:end-1)+lognoise_L2_f1(1:end-2))./(dl_f1.^2);
ypp_f2 = (lognoise_L2_f2(3:end)-2*lognoise_L2_f2(2:end-1)+lognoise_L2_f2(1:end-2))./(dl_f2.^2);
% Compute the curvature
kappa_f1= (xp_f1.*ypp_f1 - yp_f1.*xpp_f1) ./ ((xp_f1.^2 + yp_f1.^2).^(1.5));
kappa_f2= (xp_f2.*ypp_f2 - yp_f2.*xpp_f2) ./ ((xp_f2.^2 + yp_f2.^2).^(1.5));
[v1,l_f1]=max(kappa_f1);
[v2,l_f2]=max(kappa_f2);

c_f1=lambda_f1(l_f1);
c_f2=lambda_f2(l_f2);
beta_f1 = l2_beta(w,A1,Y_f1',c_f1,L,mu_f1);
beta_f2 = l2_beta(w,A1,Y_f2',c_f2,L,mu_f1);
Cerror_L2_f1=(norm(sqrt(diag(w))*(A1*beta_f1'-Y_f1')))^2;
Cnoise_L2_f1=(norm(sqrt(diag(w))*(A1*(mu_f1.*beta_f1'))))^2;

Cerror_L2_f2=(norm(sqrt(diag(w))*(A1*beta_f2'-Y_f2')))^2;
Cnoise_L2_f2=(norm(sqrt(diag(w))*(A1*(mu_f2.*beta_f2'))))^2;
 fontsize_baselinet=15;
 fontsize_baseline=15;
Color = [215,25,28;
 0 0 128;
 254,204,92;
171,217,233;
 44,123,182]/255;
 axes('position',[0.08 0.1 0.4 0.85]),
loglog(error_L2_f1,noise_L2_f1,'color',  Color(5,:),'linewidth',1.5);box on,...
hold on
loglog(Cerror_L2_f1,Cnoise_L2_f1,'r*')
set(gca, 'fontsize', fontsize_baseline),
set(gca, 'XMinorGrid', 'off'),
set(gca, 'YMinorGrid', 'off');grid on;
title('L-curve for $f_1(x)$ with $N=501,\;L=250,\;\epsilon=20$ dB','interpreter','latex', 'fontsize', fontsize_baselinet)
legend('L-curve ','Corner at $\lambda=$5.9208e-03','Interpreter','latex','Fontsize',12,'Location','NorthEast','fontsize', fontsize_baseline)
xlabel('Discrepancy $J(\lambda)$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('$K(\lambda)$', 'interpreter','latex','fontsize', fontsize_baselinet),...


axes('position',[0.56 0.1 0.4 0.85]),
loglog(error_L2_f2,noise_L2_f2,'color',  Color(5,:),'linewidth',1.5);box on,...
hold on
loglog(Cerror_L2_f2,Cnoise_L2_f2,'r*')
set(gca, 'fontsize', fontsize_baseline),
set(gca, 'XMinorGrid', 'off'),
set(gca, 'YMinorGrid', 'off');grid on;
title('L-curve for $f_2(x)$ with $N=501,\;L=250,\;\epsilon=20$ dB','interpreter','latex', 'fontsize', fontsize_baselinet)
legend('L-curve ','Corner at $\lambda=$4.5172e-08','Interpreter','latex','Fontsize',12,'Location','NorthEast','fontsize', fontsize_baseline)
xlabel('Discrepancy $J(\lambda)$','interpreter','latex', 'fontsize', fontsize_baselinet),...
ylabel('$K(\lambda)$', 'interpreter','latex','fontsize', fontsize_baselinet),...

