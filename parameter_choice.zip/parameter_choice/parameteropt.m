

% optimal parameter selecting for regularized trignometric polynomial on the unit circle
%Input: N quadrature points x and corresponding noisy data Y for trapezoidal rule.  Penalization
%parameter mu. Original function GG on grid xx.
% Please note that our plotting are set for accommodating the plotting 
% requirments in our paper. If you choose to test another function, you may
% need to modify plotting setting.
% you can try different values of parameters N.
function lambda_opt=parameteropt(N,mu,x,xx,GG,Y)
L=N-1;
 W1=ones(1,N);
w=((2*pi)/N)*W1;
%% matrix A 


 for l = 1:L+1
      for j = 1:N
          
    if mod(l, 2) == 0
        A1(j,l) =sin(((l)/2)*(x(j)))/sqrt(pi);
  
    else
      A1(j,l) = cos(((l-1)/2)*(x(j)))/sqrt(pi);
   
    end
      end
  end
   A1(:,1) =1/sqrt(2*pi);
    for l = 1:L+1
      for j = 1:length(xx)
       
    if mod(l, 2) == 0
       C(j,l) =sin(((l)/2)*(xx(j)))/sqrt(pi);
  
    else
      C(j,l) = cos(((l-1)/2)*(xx(j)))/sqrt(pi);
   
    end
      end
 end
  
C(:,1) =1/sqrt(2*pi);

lambda=2.^(-40:0.1:1);
for i=1:length(lambda)
beta = l2_beta(w,A1,Y',lambda(i),L,mu);
error_L2(i)=norm(sqrt(diag(w))*(A1*beta'-Y'))^2;
noise_L2(i)=norm(sqrt(diag(w))*(A1*(mu.*beta')))^2;
Error_L2(i)=sqrt((2*pi/N))*norm(beta*C'-GG);
end
%% lambda_opt
[v1,l1]=min(Error_L2);
lambda_opt=lambda(l1);







